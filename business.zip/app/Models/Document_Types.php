<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Document_Types extends Model
{
    use HasFactory;

    protected $table = 'document__types';
    protected $primary_key = 'id';
    public $timestamps = true;


    protected $fillable = [
        'id',
        'code',
        'name',
        'deleted_at',
        'created_at',
        'updated_at'
    ];
}
