<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Statuses extends Model
{
    use HasFactory;

    protected $table = 'statuses';
    protected $primary_key = 'id';
    public $timestamps = true;


    protected $fillable = [
        'id',
        'code',
        'name',
        'deleted_at',
        'created_at',
        'updated_at'
    ];
}
