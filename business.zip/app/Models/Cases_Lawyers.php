<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cases_Lawyers extends Model
{
    use HasFactory;

    protected $table = 'cases__lawyers';
    protected $primary_key = 'id';
    public $timestamps = true;

    protected $fillable = [
        'id',	
        'case_id',
        'lawyers_id',
        'deleted_at',
        'created_at',
        'updated_at'
    ];





}
