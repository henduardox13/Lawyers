<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cases extends Model
{
    use HasFactory;
    
    protected $table = 'cases';
    protected $primary_key = 'id';
    public $timestamps = true;
    protected $fillable = [
        'id',
        'name',
        'client_id',
        'cost',
        'status_id',
        'deleted_at',
        'created_at',
        'updated_at'
    ];


}
