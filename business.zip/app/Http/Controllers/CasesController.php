<?php

namespace App\Http\Controllers;
use App\Models\Cases;
use Illuminate\Http\Request;
use App\Models\Clients;
use App\Models\Lawyers;
use Illuminate\Support\Facades\DB;
use App\Models\Statuses;

use App\Models\Cases_Lawyers;

class CasesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $clients = Clients::where('clients.deleted_at', '=', null)
        ->select('clients.*')
        ->paginate(70);
        $lawyers = Lawyers::where('lawyers.deleted_at', '=', null)
        ->select('lawyers.*')
        ->paginate(70);
        $cases = DB::table('cases')
        ->where('cases.deleted_at', '=', null)
        ->join('clients' , 'clients.id', '=', 'cases.client_id')
        ->join('statuses' , 'statuses.id', '=', 'cases.status_id')
        ->select('cases.*' , 'clients.names' , 'clients.lastname' , 'statuses.name  as status')
        ->paginate(70);

        return view('cases.all', compact('clients', 'lawyers', 'cases'))
        ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $clients = Clients::where('clients.deleted_at', '=', null)
        ->select('clients.*' )
        ->paginate(70);
        $lawyers = Lawyers::where('lawyers.deleted_at', '=', null)
        ->select('lawyers.*' )
        ->paginate(70);
        $statuses = Statuses::where('statuses.deleted_at', '=', null)
        ->select('statuses.*' )
        ->paginate(70);
        $form = 'store';
        return view('cases.form', compact('clients','lawyers', 'form' , 'statuses'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'name' => 'required|max:255',
            'client_id' => 'required|max:255',
            'cost' =>'required|max:255',
            'status_id' =>'required|max:255',
            'lawyers_id'=>'required|max:255',
        ]);
        
        $cases = new Cases();
        $cases->client_id   =  $request->client_id;
        $cases->name        =  $request->name;
        $cases->cost        =  $request->cost;
        $cases->status_id   =  $request->status_id;
        $cases->save();
        
        foreach($request->lawyers_id as $onelawyers){
            $cases_Lawyers = new Cases_Lawyers();
            $cases_Lawyers->case_id = $cases->id;
            $cases_Lawyers->lawyers_id = $onelawyers;
            $cases_Lawyers->save();
        }    

        return redirect()->route("cases")
            ->with('success', 'action carried out successfully');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Cases  $cases
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

        $cases = Cases::where('cases.id', '=', $id)
        ->join('clients' , 'clients.id', '=', 'cases.client_id')
        ->join('statuses' , 'statuses.id', '=', 'cases.status_id')
        ->select('cases.*' , 'clients.names' , 'clients.lastname' , 'statuses.name AS status')
        ->paginate(70);

        $lawyers = Cases_Lawyers:: where('cases__lawyers.case_id', '=', $id)
        ->join('lawyers' , 'lawyers.id', '=', 'cases__lawyers.lawyers_id')
        ->select(  'lawyers.names' , 'lawyers.lastname')
        ->paginate(70);
        return view('cases.one', compact('cases', 'lawyers' ));



    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Cases  $cases
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $statuses = Statuses::where('statuses.deleted_at', '=', null)
        ->select('statuses.*' )
        ->paginate(70);
        $cases = Cases::where('cases.id', '=', $id)
        ->join('clients' , 'clients.id', '=', 'cases.client_id')
        ->join('statuses' , 'statuses.id', '=', 'cases.status_id')
        ->select('cases.*' , 'clients.names' , 'clients.lastname' , 'statuses.name AS status')
        ->paginate(70);
        $cases = $cases[0];
        $form = 'update';
        return view('cases.form', compact('form', 'cases', 'statuses' ));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Cases  $cases
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //
        $request->validate([
            'id'=>'required|max:255',    
            'status_id' =>'required|max:255',
        ]);

        $query = "update cases set";
        $query .= " status_id = '{$request->status_id}'";
        $query .= " where id  = {$request->id}";
        DB::update($query);
        return redirect()->route("cases")
            ->with('success', 'action carried out successfully');


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Cases  $cases
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $moment = date("Y-m-d H:i:s");
        $query = "update cases set";
        $query .= " deleted_at = '{$moment}',";  
        $query .= " status_id =  4";  
        $query .= " where id  = {$id}";  
        DB::update($query);
        return redirect()->route("clients")
        ->with('success', 'record deleted successfully');


    }
}
