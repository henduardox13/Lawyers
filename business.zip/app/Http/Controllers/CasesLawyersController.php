<?php

namespace App\Http\Controllers;

use App\Models\Cases_Lawyers;
use Illuminate\Http\Request;

class CasesLawyersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Cases_Lawyers  $cases_Lawyers
     * @return \Illuminate\Http\Response
     */
    public function show(Cases_Lawyers $cases_Lawyers)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Cases_Lawyers  $cases_Lawyers
     * @return \Illuminate\Http\Response
     */
    public function edit(Cases_Lawyers $cases_Lawyers)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Cases_Lawyers  $cases_Lawyers
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cases_Lawyers $cases_Lawyers)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Cases_Lawyers  $cases_Lawyers
     * @return \Illuminate\Http\Response
     */
    public function destroy(Cases_Lawyers $cases_Lawyers)
    {
        //
    }
}
