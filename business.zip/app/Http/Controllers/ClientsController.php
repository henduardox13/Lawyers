<?php

namespace App\Http\Controllers;
use App\Models\Clients;
use Illuminate\Http\Request;
use App\Models\Document_Types;
use Illuminate\Support\Facades\DB;

class ClientsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $clients = Clients::where('clients.deleted_at', '=', null)
        ->join('document__types' , 'clients.document_type_id', '=', 'document__types.id')
        ->select('clients.*' , 'document__types.name')
        ->paginate(70);
        return view('clients.all', compact('clients'))
        ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $form = 'store';
        $document = Document_Types::get();
        return view('clients.form', compact('form','document' ));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'names' => 'required|max:255',
            'lastname' => 'required|max:255',
            'code' =>'required|max:255',
            'document_type_id' =>'required|max:255',
            'document_number' =>'required|max:255',
        ]);

        $clients = new Clients();
        $clients->names = $request->names;
        $clients->lastname = $request->lastname;
        $clients->code = $request->code;
        $clients->document_type_id = $request->document_type_id;
        $clients->document_number = $request->document_number;
        $clients->save();    
        return redirect()->route("clients")
            ->with('success', 'action carried out successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Clients  $clients
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $clients =  Clients::where('clients.id', '=', $id)
        ->join('document__types' , 'clients.document_type_id', '=', 'document__types.id')
        ->select('clients.names', 'clients.lastname' , 'clients.code', 'document__types.name')
        ->paginate(70);
       return view('clients.one', compact('clients' ));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Clients  $clients
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $clients =  Clients::where('clients.id', '=', $id)
        ->join('document__types' , 'clients.document_type_id', '=', 'document__types.id')
        ->select('clients.*' , 'document__types.name')
        ->paginate(70);
        $clients = $clients[0];
        $form = 'update';
        $document = Document_Types::get();
        return view('clients.form', compact('form','document', 'clients' ));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Clients  $clients
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //
        $request->validate([
            'id'=> 'required|max:255',
            'names' => 'required|max:255',
            'lastname' => 'required|max:255',
            'code' =>'required|max:255',
            'document_type_id' =>'required|max:255',
            'document_number' =>'required|max:255',
        ]);
       
        $query = "update clients set";
        $query .= " names = '{$request->names}',"; 
        $query .= " lastname = '{$request->lastname}',";       
        $query .= " code = '{$request->code}',";    
        $query .= " document_type_id = {$request->document_type_id},";    
        $query .= " document_number = '{$request->document_number}'";    
        $query .= " where id  = {$request->id}";
        DB::update($query);
        
        return redirect()->route("clients")
            ->with('success', 'action carried out successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Clients  $clients
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $moment = date("Y-m-d H:i:s");
        $query = "update clients set";
        $query .= " deleted_at = '{$moment}'";  
        $query .= " where id  = {$id}";  
        DB::update($query);
        return redirect()->route("clients")
        ->with('success', 'record deleted successfully');
    }
}
