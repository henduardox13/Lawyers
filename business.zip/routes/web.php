<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('welcome');
});
*/

Auth::routes();
/*
    Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
*/
/* lawyers */
Route::get('/lawyers', [App\Http\Controllers\LawyersController::class, 'index'])->name('lawyers');
Route::get('/lawyers/{id}', [App\Http\Controllers\LawyersController::class, 'show']);
Route::get('/lawyers.create', [App\Http\Controllers\LawyersController::class, 'create']);
Route::post('/lawyers.store', [App\Http\Controllers\LawyersController::class, 'store']);
Route::get('/lawyers.edit/{id}', [App\Http\Controllers\LawyersController::class, 'edit']);
Route::post('/lawyers.update', [App\Http\Controllers\LawyersController::class, 'update']);
Route::get('/lawyers.destroy/{id}', [App\Http\Controllers\LawyersController::class, 'destroy']);

/*clients */
Route::get('/clients', [App\Http\Controllers\ClientsController::class, 'index'])->name('clients');
Route::get('/clients/{id}', [App\Http\Controllers\ClientsController::class, 'show']);
Route::get('/clients.create', [App\Http\Controllers\ClientsController::class, 'create']);
Route::post('/clients.store', [App\Http\Controllers\ClientsController::class, 'store']);
Route::get('/clients.edit/{id}', [App\Http\Controllers\ClientsController::class, 'edit']);
Route::post('/clients.update', [App\Http\Controllers\ClientsController::class, 'update']);
Route::get('/clients.destroy/{id}', [App\Http\Controllers\ClientsController::class, 'destroy']);


/*Cases */
Route::get('/cases', [App\Http\Controllers\CasesController::class, 'index'])->name('cases');
Route::get('/cases/{id}', [App\Http\Controllers\CasesController::class, 'show']);
Route::get('/cases.create', [App\Http\Controllers\CasesController::class, 'create']);
Route::post('/cases.store', [App\Http\Controllers\CasesController::class, 'store']);
Route::get('/cases.edit/{id}', [App\Http\Controllers\CasesController::class, 'edit']);
Route::post('/cases.update', [App\Http\Controllers\CasesController::class, 'update']);
Route::get('/cases.destroy/{id}', [App\Http\Controllers\CasesController::class, 'destroy']);
