@extends('layouts.app')

@section('content')

<div class="col-md-12">
    <h1> Cases </h1>
    <hr>
    @if(count($clients) > 0 && count($lawyers) > 0 )
        <a href="{{ url('/cases.create') }}" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Add Cases <i class="far fa-star"></i></a>
    @endif
        <br/> <br/>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="table-responsive">
        @if(isset($cases))
        <table class="table  table-borderless">
            <thead class="">
                <tr>
                    <th>Name </th>
                    <th>Client</th>
                    <th>Cost </th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($cases as $row)
                <tr>
                    <td>{{$row->name}}</td>
                    <td>{{$row->names}}</td>
                    <td>{{$row->cost}}</td>
                    <td>{{$row->status  ?? null}}</td>
                    <td> 
                       <a href="{{ url('/cases.edit/'.$row->id ) }}"> Edit </a>
                       <a href="{{ url('/cases/'.$row->id) }}"> Show </a>
                       <a href="{{ url('/cases.destroy/'.$row->id) }}"> Delete </a>
                    </td>
                </tr>
                @endforeach
 
            </tbody>
        </table>
        {{  $cases->links()  }}
        @endif
    
    </div> 
</div>
   


@endsection
