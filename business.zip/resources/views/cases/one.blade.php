@extends('layouts.app')

@section('content')

    <div class="col-md-12 row">
        <div class="form-group col-md-12">
            <h1> Show </h1>
            <hr>
        </div>    
        @foreach($cases as $row)     
            <div class="form-group col-md-12">
                <label> <b> name :</b> {{ $row->name  }} </label><br>
                <label> <b> client :</b> {{ $row->names  }}  {{ $row->lastname }}</label><br>
                <label> <b> cost :</b> {{ $row->cost }} </label><br>
                <label> <b> Status : </b> {{ $row->status}} </label><br>
            </div>  
        @endforeach

        @foreach($lawyers as $row)     
            <div class="form-group col-md-12">
                <label> <u><b> Lawyers</b></u></label><br>
                <label>  {{ $row->names  }} {{ $row->lastname }} </label><br>
            </div>  
        @endforeach
        


    </div>
   
       
     


@endsection
