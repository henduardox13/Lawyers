@extends('layouts.app')

@section('content')
<form class="col-md-12 row"  method="POST" action="/cases.{{ $form }}">
    @csrf
    <br>


    @if ($errors->any())
    <div class="alert alert-danger col-md-12">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    @if($form != 'store')
    <div class="form-group col-md-12">
        <h1> Edit </h1>
        <hr>
    </div>    
        <input  type="hidden" name="id" id="id"  class="form-control"  value="{{ $cases->id }}" required>
    
    @else
        <div class="form-group col-md-12">
            <h1> New </h1>
            <hr>
        </div>   


        <div class="form-group col-md-12">
            <label> client   *</label>
                <select  type="text" name="client_id" id="client_id"   class="form-control" required>
                        <option   option value="{{  null }}"> {{  null }} </option>
                    @foreach($clients  as $row)
                         <option value="{{$row->id }}"> {{ $row->names }} </option>   
                    @endforeach
                </select>    
        </div>


        <div class="form-group col-md-12">
            <label> lawyers  * "multiple"</label>
                <select  type="text" name="lawyers_id[]" id="lawyers_id"   class="form-control" required multiple>
                        <option   option value="{{  null }}"> {{  null }} </option>
                    @foreach($lawyers  as $row)
                         <option value="{{$row->id }}"> {{ $row->names}} </option>   
                    @endforeach
                </select>    
        </div>

        <div class="form-group col-md-12">
            <label> cost *</label>
            <input  type="number" name="cost" id="cost" placeholder="name"  class="form-control" value="{{ $cases->cost ?? null }}" required>
        </div>
        <div class="form-group col-md-12">
            <label> name *</label>
            <input  type="text" name="name" id="name" placeholder="name"  class="form-control" value="{{ $cases->name ?? null }}" required>
        </div>
    @endif 
    

    <div class="form-group col-md-12">
        <label> status  *</label>
            <select  type="text" name="status_id" id="status_id"   class="form-control" required>
                    <option   option value="{{ $cases->status_id ?? null }}"> {{ $cases->status ?? null }} </option>
                @foreach($statuses  as $row)
                     <option value="{{$row->id }}"> {{ $row->name }} </option>   
                @endforeach
            </select>    
    </div>
    
      
    
    <div class="form-group col-md-12">
        <button type="submit" class="btn btn-primary"> save</button>
    </div>



</form>


@endsection
