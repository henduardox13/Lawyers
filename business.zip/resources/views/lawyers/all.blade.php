@extends('layouts.app')

@section('content')

<div class="col-md-12">
    <h1> Lawyers </h1>
    <hr>

    <a href="{{ url('/lawyers.create') }}" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Add Lawyers <i class="far fa-star"></i></a>
    <br/> <br/>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="table-responsive">
        @if(isset($lawyers))
        <table class="table  table-borderless">
            <thead class="">
                <tr>
                    <th>Names</th>
                    <th>Lastname</th>
                    <th>Document Types</th>
                    <th> Document number</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($lawyers as $row)
                <tr>
                    <td>{{$row->names}}</td>
                    <td>{{$row->lastname}}</td>
                    <td>{{$row->name}}</td>
                    <td>{{$row->document_number}}</td>
                    <td> 
                       <a href="{{ url('/lawyers.edit/'.$row->id ) }}"> Edit </a>
                       <a href="{{ url('/lawyers/'.$row->id) }}"> Show </a>
                       <a href="{{ url('/lawyers.destroy/'.$row->id) }}"> Delete </a>
                    </td>
                </tr>
                @endforeach
 
            </tbody>
        </table>
        {{  $lawyers->links()  }}
        @endif
    
    </div> 
</div>
   


@endsection
