@extends('layouts.app')

@section('content')

<div class="col-md-12">
    <h1> Clients </h1>
    <hr>

    <a href="{{ url('/clients.create') }}" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Add Clients <i class="far fa-star"></i></a>
    <br/> <br/>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="table-responsive">
        @if(isset($clients))
        <table class="table  table-borderless">
            <thead class="">
                <tr>
                    <th>Names</th>
                    <th>Lastname</th>
                    <th>Document Types</th>
                    <th> Document number</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($clients as $row)
                <tr>
                    <td>{{$row->names}}</td>
                    <td>{{$row->lastname}}</td>
                    <td>{{$row->name}}</td>
                    <td>{{$row->document_number}}</td>
                    <td> 
                       <a href="{{ url('/clients.edit/'.$row->id ) }}"> Edit </a>
                       <a href="{{ url('/clients/'.$row->id) }}"> Show </a>
                       <a href="{{ url('/clients.destroy/'.$row->id) }}"> Delete </a>
                    </td>
                </tr>
                @endforeach
 
            </tbody>
        </table>
        {{  $clients->links()  }}
        @endif
    
    </div> 
</div>
   


@endsection
