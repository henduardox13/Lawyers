@extends('layouts.app')

@section('content')
<form class="col-md-12 row"  method="POST" action="/clients.{{ $form }}">
    @csrf
    <br>


    @if ($errors->any())
    <div class="alert alert-danger col-md-12">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    @if($form != 'store')
    <div class="form-group col-md-12">
        <h1> Edit </h1>
        <hr>
    </div>    
        <input  type="hidden" name="id" id="id"  class="form-control"  value="{{ $clients->id }}" required>
    @else
        <div class="form-group col-md-12">
            <h1> New </h1>
            <hr>
        </div>    

    @endif 
    <div class="form-group col-md-12">
        <label> names *</label>
        <input  type="text" name="names" id="names" placeholder="names"  class="form-control" value="{{ $clients->names ?? null }}" required>
    </div>
    <div class="form-group col-md-12">
        <label> lastname *</label>
        <input  type="text" name="lastname" id="lastname" placeholder="lastname"  class="form-control" value="{{ $clients->lastname ?? null }}" required>
    </div>
    <div class="form-group col-md-12">
        <label> code *</label>
        <input  type="text" name="code" id="code" placeholder="code"  class="form-control" value="{{ $clients->code ?? null }}" required>
    </div>
    <div class="form-group col-md-12">
        <label> document type *</label>
            <select  type="text" name="document_type_id" id="document_type_id"   class="form-control" required>
                    <option   option value="{{ $clients->document_type_id ?? null }}"> {{ $clients->name ?? null }} </option>
                @foreach($document as $row)
                     <option value="{{$row->id }}"> {{ $row->name }} </option>   
                @endforeach
            </select>    

    </div>
    <div class="form-group col-md-12">
        <label> document number *</label>
        <input  type="number" name="document_number" id="document_number" placeholder="document number"  class="form-control" value="{{ $clients->document_number ?? null }}" required>
    </div>



    <div class="form-group col-md-12">
        <button type="submit" class="btn btn-primary"> save</button>
    </div>
      
    




</form>


@endsection
