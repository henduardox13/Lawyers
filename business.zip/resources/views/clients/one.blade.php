@extends('layouts.app')

@section('content')

    <div class="col-md-12 row">
        <div class="form-group col-md-12">
            <h1> Show </h1>
            <hr>
        </div>    
        @foreach($clients as $row)     
            <div class="form-group col-md-12">
                <label> <b> names :</b> {{ $row->names  }} </label><br>
                <label> <b> lastname :</b> {{ $row->lastname }} </label><br>
                <label> <b> code :</b> {{ $row->code }} </label><br>
                <label> <b> document type : </b> {{ $row->name }} </label><br>
                <label> <b> document number :</b> {{ $row->document_number }} </label><br>
            </div>  
        @endforeach
        


    </div>
   
       
     


@endsection
