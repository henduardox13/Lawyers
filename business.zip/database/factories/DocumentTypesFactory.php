<?php

namespace Database\Factories;

use App\Models\Document_Types;
use Illuminate\Database\Eloquent\Factories\Factory;

class Document_TypesFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Document_Types::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
