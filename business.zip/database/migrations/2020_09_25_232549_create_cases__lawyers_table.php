<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCasesLawyersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cases__lawyers', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('case_id');
            $table->unsignedBigInteger('lawyers_id');
            $table->dateTime('deleted_at')->nullable();
            $table->timestamps();
            $table->foreign('case_id')->references('id')->on('cases');
            $table->foreign('lawyers_id')->references('id')->on('lawyers');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cases__lawyers');
    }
}
