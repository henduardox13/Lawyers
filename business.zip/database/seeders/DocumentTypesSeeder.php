<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DocumentTypesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('document__types')->insert([
            'code' => 'IC',
            'name' => ' identification card',
        ]);
        DB::table('document__types')->insert([
            'code' => 'PS',
            'name' => 'passport',
        ]);
        DB::table('document__types')->insert([
            'code' => 'PS',
            'name' => 'license',
        ]);
        DB::table('document__types')->insert([
            'code' => 'O',
            'name' => 'other',
        ]);
        


    }
}
